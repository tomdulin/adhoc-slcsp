require 'pry'
require 'singleton'
require "slcsp/version"
require 'slcsp/storable'
require 'slcsp/log'
require 'slcsp/reader'
require 'slcsp/slcsp_data'
require 'slcsp/zips_data'
require "slcsp/cli"
require "slcsp/datum"
require "slcsp/plans_data"

